from flask import Flask, request, render_template, jsonify
from flask_cors import *
import time
import pymysql
import json
import copy

app = Flask(__name__,static_url_path='/static/',template_folder='templates')
CORS(app, resources=r'/*')

mysql_path="82.156.28.161"
mysql_user="mysql"
mysql_pass="xiaochuang12345"
mysql_db="xiaochuang"

ip="localhost"

# 主页
@app.route('/')
def index():
    return render_template("index.html")

# 学科页

@app.route('/subject=<subject>')
def direct_to_subject_page(subject):
    db = pymysql.connect(mysql_path, mysql_user, mysql_pass, mysql_db)
    cursor = db.cursor()
    sql = """
                select title,organizer,introduction,date_format(starttime,'%Y-%m-%d') from lecture where field like '%{}%';
                """.format(subject)
    cursor.execute(sql)
    data = cursor.fetchall()

    # print(len(data))

    lecture_list = []

    for i in data:
        temp = {}
        if len(i[0])<=40:
            temp['title'] = i[0]
        else:
            temp['title'] = i[0][:40]+'...'
        temp['organizer'] = i[1]
        temp['introduction'] = i[2]
        temp['time'] = i[3]
        # print(temp['time'])
        lecture_list.append(copy.deepcopy(temp))

    # print(len(lecture_list))
    return render_template("subject_demo.html", lecture_list=lecture_list)
    # return render_template("subject_demo.html")

# 搜索结果页

@app.route('/search=<keyword>')
def direct_to_search_result_page(keyword):
    db = pymysql.connect(mysql_path, mysql_user, mysql_pass, mysql_db)
    cursor = db.cursor()
    sql = """
            select title,organizer,introduction,date_format(starttime,'%Y-%m-%d') from lecture where title like '%{}%';
            """.format(keyword)
    cursor.execute(sql)
    data = cursor.fetchall()

    # print(len(data))

    lecture_list = []

    for i in data:
        temp = {}
        temp['title'] = i[0]
        temp['organizer'] = i[1]
        temp['introduction'] = i[2]
        temp['time'] = i[3]
        # print(temp['time'])
        lecture_list.append(copy.deepcopy(temp))

    # print(len(lecture_list))
    return render_template("subject_demo.html", lecture_list = lecture_list)
    # return render_template("subject_demo.html")

if __name__ == '__main__':
    app.run('0.0.0.0', 5000)