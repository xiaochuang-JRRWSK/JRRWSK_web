# 上海大学语料收集
## 网址：http://sjc.shu.edu.cn/tg/xsjz.htm
## SHU.xlsx：至2020/2/24日，上述网址中所有讲座类通知的链接，共48条
![Image text](https://github.com/JJYDXFS/little-innovation/blob/master/Text_Materials/Website/SHU/img/xlsx.jpg?raw=true)
## SHU_Text.zip：SHU.xlsx中所有链接对应的文本
![Image text](https://github.com/JJYDXFS/little-innovation/blob/master/Text_Materials/Website/SHU/img/txt.jpg?raw=true)
## SHU_getContent.PY：代码
