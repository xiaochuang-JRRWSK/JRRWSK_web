# 学校或机构官网语料收集说明（讲座预告类）
## SCUT：[华南理工大学 学术预告](https://www.scut.edu.cn/new/9010/list.htm)  1136条
## ECNU：[华东师范大学传播学院 讲座预告](http://www.comm.ecnu.edu.cn/htmlaction.do?method=toGetSubNewsList&menuType=7&pageNo=0)  18条
## SHU：[上海大学新闻传播学院 学术讲座](http://sjc.shu.edu.cn/tg/xsjz.htm) 48条
