# 华南理工大学语料收集
## 网址：https://www.scut.edu.cn/new/9010/list.htm
## SCUT.xlsx：至2020/2/23日，上述网址中所有讲座类通知的链接，共1136条
![Image text](https://github.com/JJYDXFS/little-innovation/blob/master/Text_Materials/Website/SCUT/img/SCUT.jpg?raw=true)
## SCUT_Text.zip：SCUT.xlsx中所有链接对应的文本
![Image text](https://github.com/JJYDXFS/little-innovation/blob/master/Text_Materials/Website/SCUT/img/SCUT_content.jpg?raw=true)
## SCUT.PY：获取内链的代码
## SCUT_getContent.PY：获取内链中文本内容的代码
*一点说明：之所以将收集链接与获取文本拆成两个步骤，是为了方便debug。在获取文本时需要开启浏览器，爬取速度变慢，也会因bug出现各种中断的情况，为了方便对齐找错，故而拆成两个步骤。*
