# 华东师范大学语料收集
## 网址：http://www.comm.ecnu.edu.cn/htmlaction.do?method=toGetSubNewsList&menuType=7&pageNo=0
## ECNU.xlsx：至2020/2/24日，上述网址中所有讲座类通知的链接，共120条，其中有效连接18条
错误链接均已在表格中标注，具体表现为页面打开没有内容<br>
eg: 2019-12-11日发布的一条预告：[讲座预告 | 商艳青：数据和AI 媒体大脑双引擎推动媒体智能化     2019-12-11](http://www.comm.ecnu.edu.cn/htmlaction.do?method=toHtmlDetail&htmlId=1141)<br>
（这个网站，起码这个站点，看上去并没有好好维护）
![Image text](https://github.com/JJYDXFS/little-innovation/blob/master/Text_Materials/Website/ECNU/img/%E9%94%99%E8%AF%AF%E9%A1%B5%E9%9D%A2.jpg?raw=true)
## ECNU_Text.zip：ECNU.xlsx中有效链接对应的文本
![Image text](https://github.com/JJYDXFS/little-innovation/blob/master/Text_Materials/Website/ECNU/img/%E5%B0%B1%E8%BF%99%E4%B9%88%E5%A4%9A%E4%BA%86.jpg?raw=true)
## ECNU_getContent.PY：代码
*说明：该批语料均属新闻传播类，网站问题使得大部分内容失效*
