# 微信语料收集说明（讲座预告类）
## 1.url_List.xlsx
表格中收集信息格式如图，共304条
![Image text](https://raw.githubusercontent.com/JJYDXFS/little-innovation/master/Text_Materials/WeChat/img/xlsx.jpg)
## 2.微信公众号文本素材.zip
获取url_List.xlsx中收集的文章文本，并以txt格式保存
如图每个txt中均标注了原文链接/公众号信息/正文
![Image text](https://raw.githubusercontent.com/JJYDXFS/little-innovation/master/Text_Materials/WeChat/img/txt.jpg)
## 3.WeChat_getContent.py
源代码
